const tg = window.Telegram?.WebApp;
if (tg) {
    tg.ready();
    tg.expand();
    try { tg.setHeaderColor("#090710"); tg.setBackgroundColor("#090710"); } catch (e) {}
}
const initData = tg?.initData || "";
const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const fmt = (n) => Number(n).toLocaleString("ru-RU");
const esc = (v) => String(v).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
})[c]);

let CFG = null;
let ME = null;

// ---------- утилиты ----------
let toastTimer;
function toast(msg) {
    const el = $("toast");
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}

async function notifyAch(list) {
    for (const a of list || []) {
        toast(`🏆 Достижение: ${a.title}`);
        await sleep(2800);
    }
}

async function api(url, method = "GET", body) {
    const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json", "Authorization": `tma ${initData}` },
        body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
        const d = data.detail;
        throw new Error(typeof d === "string" ? d : "Произошла ошибка");
    }
    return data;
}

function setStars(n) {
    if (ME) ME.stars = n;
    $("balance").textContent = fmt(n);
}

function openModal(html) {
    $("modalBody").innerHTML = html;
    $("modal").classList.remove("hidden");
}
function closeModal() { $("modal").classList.add("hidden"); }
$("modal").addEventListener("click", (e) => { if (e.target.id === "modal") closeModal(); });
window.closeModal = closeModal;

// ---------- навигация ----------
function switchPage(name) {
    document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === name));
    document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.page === name));
    if (name === "rating") loadLeaderboard();
    if (name === "games") { renderUpgrade(); }
    if (name === "inventory" || name === "home") refreshMe();
}
document.querySelectorAll(".tab").forEach(t => t.addEventListener("click", () => switchPage(t.dataset.page)));
$("balanceBox").addEventListener("click", () => switchPage("home"));

function switchGame(name) {
    document.querySelectorAll(".game").forEach(g => g.classList.toggle("active", g.id === `game-${name}`));
    document.querySelectorAll(".subtab").forEach(t => t.classList.toggle("active", t.dataset.game === name));
    if (name === "upgrade") renderUpgrade();
    if (name === "mines") loadMines();
    if (name === "crash") loadCrash();
}
document.querySelectorAll(".subtab").forEach(t => t.addEventListener("click", () => switchGame(t.dataset.game)));

// ---------- профиль ----------
async function refreshMe() {
    try {
        ME = await api("/api/me");
        setStars(ME.stars);
        $("username").textContent = ME.username || "Игрок";
        renderAchievements();
        renderInventory();
        renderUpgrade();
    } catch (e) { toast(e.message); }
}

function renderAchievements() {
    const done = ME.achievements.filter(a => a.unlocked).length;
    $("achCount").textContent = `${done}/${ME.achievements.length}`;
    $("achievements").innerHTML = ME.achievements.map(a => `
        <div class="ach ${a.unlocked ? "done" : ""}">
            <span class="emoji">${a.emoji}</span>
            <div><b>${esc(a.title)}</b>
            <small>${esc(a.desc)}${a.unlocked ? "" : ` · ${fmt(a.progress)}/${fmt(a.need)}`}</small></div>
        </div>`).join("");
}

function renderInventory() {
    $("invCount").textContent = ME.inventory.length;
    if (!ME.inventory.length) {
        $("items").innerHTML = `<p class="muted">Пока пусто. Открой кейс!</p>`;
        return;
    }
    $("items").innerHTML = ME.inventory.map(i => `
        <div class="item-row ${i.type === "nft" ? "nft" : ""}">
            <span class="emoji">${i.emoji}</span>
            <div class="grow">${esc(i.name)}<small>${i.type === "nft" ? "NFT · " : ""}${fmt(i.value)} ⭐</small></div>
            ${i.status === "owned" ? `
            <div class="btns">
                <button class="primary-button small" onclick="sellItem(${i.id})">Продать</button>
                <button class="primary-button small green" onclick="withdrawItem(${i.id})">Вывести</button>
            </div>` : `<span class="muted">⏳ вывод</span>`}
        </div>`).join("");
}

async function sellItem(id) {
    try {
        const r = await api("/api/sell", "POST", { item_id: id });
        setStars(r.stars);
        toast(`Продано за ${fmt(r.sold)} ⭐`);
        closeModal();
        refreshMe();
    } catch (e) { toast(e.message); }
}

async function withdrawItem(id) {
    if (!confirm("Вывести подарок? Админ отправит его вручную.")) return;
    try {
        await api("/api/withdraw", "POST", { item_id: id });
        toast("Заявка отправлена админу");
        closeModal();
        refreshMe();
    } catch (e) { toast(e.message); }
}
window.sellItem = sellItem;
window.withdrawItem = withdrawItem;

// ---------- бонус и пополнение ----------
$("bonusButton").addEventListener("click", async () => {
    try {
        const r = await api("/api/bonus", "POST");
        setStars(r.stars);
        toast(r.message);
    } catch (e) { toast(e.message); }
});

function renderDeposits() {
    $("deposits").innerHTML = CFG.deposits.map(a =>
        `<button class="deposit-btn" onclick="deposit(${a})">${fmt(a)} ⭐</button>`).join("");
}

async function deposit(amount) {
    if (!tg || !initData) { toast("Открой Mini App через Telegram."); return; }
    try {
        const r = await api("/api/invoice", "POST", { amount });
        tg.openInvoice(r.invoice_url, async (status) => {
            if (status === "paid") {
                toast("Оплата прошла, зачисляем...");
                for (let i = 0; i < 6; i++) { await sleep(1500); await refreshMe(); }
            } else if (status === "cancelled") toast("Оплата отменена");
            else if (status === "failed") toast("Не удалось провести оплату");
        });
    } catch (e) { toast(e.message); }
}
window.deposit = deposit;

// ---------- кейсы ----------
function renderCases() {
    $("caseList").innerHTML = CFG.cases.map(c => `
        <div class="case-card" onclick="showCase('${c.id}')">
            <div class="emoji">${c.emoji}</div>
            <h3>${esc(c.name)}</h3>
            <div class="price">${fmt(c.price)} ⭐</div>
        </div>`).join("");
}

function showCase(id) {
    const c = CFG.cases.find(x => x.id === id);
    openModal(`
        <h2>${c.emoji} ${esc(c.name)}</h2>
        <div id="reelBox"></div>
        <div class="drop-list">${c.drops.map(d => `
            <div><span>${d.emoji} ${esc(d.name)}${d.type === "nft" ? " · NFT" : ""}</span>
            <span>${fmt(d.value)} ⭐ · ${d.chance}%</span></div>`).join("")}</div>
        <div class="modal-actions">
            <button class="primary-button" id="openCaseBtn" onclick="openCase('${c.id}')">Открыть за ${fmt(c.price)} ⭐</button>
            <button class="primary-button danger" onclick="closeModal()">Закрыть</button>
        </div>`);
}

let opening = false;
async function openCase(id) {
    if (opening) return;
    opening = true;
    const c = CFG.cases.find(x => x.id === id);
    try {
        const r = await api("/api/case/open", "POST", { case_id: id });
        setStars(r.stars);
        // рулетка
        const cells = [];
        for (let i = 0; i < 40; i++) cells.push(c.drops[Math.floor(Math.random() * c.drops.length)].emoji);
        const winIndex = 34;
        cells[winIndex] = r.item.emoji;
        $("reelBox").innerHTML = `<div class="reel"><div class="reel-strip" id="strip">
            ${cells.map(e => `<div class="reel-cell">${e}</div>`).join("")}</div></div>`;
        const strip = $("strip");
        const width = strip.parentElement.clientWidth;
        const target = winIndex * 84 - width / 2 + 42 + (Math.random() * 40 - 20);
        await sleep(50);
        strip.style.transform = `translateX(${-target}px)`;
        await sleep(3800);
        showResult(r.item, c);
        notifyAch(r.achievements);
    } catch (e) {
        toast(e.message);
    } finally {
        opening = false;
    }
}
window.showCase = showCase;
window.openCase = openCase;

function showResult(item, c) {
    openModal(`
        <h2>Тебе выпало!</h2>
        <div class="result-emoji">${item.emoji}</div>
        <h3>${esc(item.name)}</h3>
        <p class="muted">${item.type === "nft" ? "NFT · " : ""}${fmt(item.value)} ⭐</p>
        <div class="modal-actions">
            <button class="primary-button green" onclick="sellItem(${item.id})">Продать ${fmt(item.value)} ⭐</button>
            <button class="primary-button" onclick="showCase('${c.id}')">Ещё раз</button>
        </div>
        <div class="modal-actions"><button class="primary-button danger" onclick="closeModal(); refreshMe()">В инвентарь</button></div>`);
}
window.refreshMe = refreshMe;

// ---------- апгрейд ----------
let upSel = new Set();
let upTarget = null;

function upChance(valueIn, valueTarget) {
    return Math.min(0.75, valueIn / valueTarget * (1 - CFG.upgrade_edge));
}

function renderUpgrade() {
    if (!ME || !CFG) return;
    const owned = ME.inventory.filter(i => i.status === "owned");
    upSel = new Set([...upSel].filter(id => owned.some(i => i.id === id)));
    $("upInv").innerHTML = owned.length ? owned.map(i => `
        <div class="mini ${upSel.has(i.id) ? "selected" : ""} ${i.type === "nft" ? "nft" : ""}" onclick="toggleUp(${i.id})">
            <span class="emoji">${i.emoji}</span>${esc(i.name)}<br>${fmt(i.value)} ⭐
        </div>`).join("") : `<p class="muted" style="grid-column:1/-1">Нет предметов. Открой кейс.</p>`;

    const valueIn = owned.filter(i => upSel.has(i.id)).reduce((s, i) => s + i.value, 0);
    const targets = valueIn ? CFG.gifts.filter(g => g.value > valueIn && upChance(valueIn, g.value) >= 0.01)
        .sort((a, b) => a.value - b.value) : [];
    if (upTarget && !targets.some(t => t.key === upTarget)) upTarget = null;
    $("upTargets").innerHTML = targets.length ? targets.map(g => `
        <div class="mini ${upTarget === g.key ? "selected" : ""} ${g.type === "nft" ? "nft" : ""}" onclick="pickTarget('${g.key}')">
            <span class="emoji">${g.emoji}</span>${esc(g.name)}<br>${fmt(g.value)} ⭐<br>
            ${(upChance(valueIn, g.value) * 100).toFixed(1)}%
        </div>`).join("") : `<p class="muted" style="grid-column:1/-1">Сначала выбери предметы</p>`;

    const target = CFG.gifts.find(g => g.key === upTarget);
    if (valueIn && target) {
        $("upChance").textContent = `${(upChance(valueIn, target.value) * 100).toFixed(1)}%`;
        $("upInfo").textContent = `${fmt(valueIn)} ⭐ → ${target.name} (${fmt(target.value)} ⭐)`;
        $("upGo").disabled = false;
    } else {
        $("upChance").textContent = "—";
        $("upInfo").textContent = "Выбери предметы и цель";
        $("upGo").disabled = true;
    }
}

function toggleUp(id) {
    if (upSel.has(id)) upSel.delete(id);
    else if (upSel.size < 5) upSel.add(id);
    else toast("Максимум 5 предметов");
    renderUpgrade();
}
function pickTarget(key) { upTarget = key; renderUpgrade(); }
window.toggleUp = toggleUp;
window.pickTarget = pickTarget;

$("upGo").addEventListener("click", async () => {
    $("upGo").disabled = true;
    try {
        const r = await api("/api/upgrade", "POST", { item_ids: [...upSel], target: upTarget });
        upSel.clear(); upTarget = null;
        openModal(r.win ? `
            <h2>⚡ Успех!</h2><div class="result-emoji">${r.item.emoji}</div>
            <h3>${esc(r.item.name)}</h3><p class="muted">Шанс был ${r.chance}%</p>
            <div class="modal-actions"><button class="primary-button" onclick="closeModal()">Круто</button></div>` : `
            <h2>💥 Не повезло</h2><div class="result-emoji">💨</div>
            <p class="muted">Шанс был ${r.chance}%. Предметы сгорели.</p>
            <div class="modal-actions"><button class="primary-button" onclick="closeModal()">Ок</button></div>`);
        await refreshMe();
        notifyAch(r.achievements);
    } catch (e) { toast(e.message); renderUpgrade(); }
});

// ---------- сапёр ----------
let mines = { active: false };

function renderMines(extra = {}) {
    const board = $("minesBoard");
    const revealed = new Set(mines.revealed || []);
    const mineCells = new Set(extra.mine_cells || []);
    let html = "";
    for (let i = 0; i < 25; i++) {
        let cls = "cell", label = "", dis = !mines.active;
        if (revealed.has(i)) { cls += " safe"; label = "💎"; dis = true; }
        else if (mineCells.has(i)) { cls += " mine"; label = "💣"; dis = true; }
        html += `<button class="${cls}" ${dis ? "disabled" : ""} onclick="revealCell(${i})">${label}</button>`;
    }
    board.innerHTML = html;
    $("minesStart").disabled = !!mines.active;
    $("minesCash").disabled = !(mines.active && (mines.revealed || []).length > 0);
    if (mines.active) {
        $("minesInfo").textContent = `x${mines.multiplier.toFixed(2)} · сейчас ${fmt(mines.payout)} ⭐` +
            (mines.next_multiplier ? ` · следующая x${mines.next_multiplier.toFixed(2)}` : "");
        $("minesCash").textContent = `Забрать ${fmt(mines.payout)} ⭐`;
    } else {
        $("minesCash").textContent = "Забрать";
    }
}

async function loadMines() {
    try { mines = await api("/api/mines/state"); renderMines(); } catch (e) { toast(e.message); }
}

$("minesStart").addEventListener("click", async () => {
    try {
        const r = await api("/api/mines/start", "POST", {
            bet: parseInt($("minesBet").value, 10), mines: parseInt($("minesCount").value, 10)
        });
        mines = r; setStars(r.stars); renderMines();
    } catch (e) { toast(e.message); }
});

async function revealCell(i) {
    try {
        const r = await api("/api/mines/reveal", "POST", { cell: i });
        mines = r;
        if (r.result === "lost") {
            renderMines({ mine_cells: r.mine_cells });
            $("minesInfo").textContent = "💥 Мина! Ставка потеряна";
            refreshMe(); notifyAch(r.achievements);
        } else if (r.result === "cashed") {
            setStars(r.stars); renderMines({ mine_cells: r.mine_cells });
            $("minesInfo").textContent = `🎉 Всё открыто! +${fmt(r.win)} ⭐`;
            refreshMe(); notifyAch(r.achievements);
        } else renderMines();
    } catch (e) { toast(e.message); }
}
window.revealCell = revealCell;

$("minesCash").addEventListener("click", async () => {
    try {
        const r = await api("/api/mines/cashout", "POST");
        mines = r; setStars(r.stars);
        renderMines({ mine_cells: r.mine_cells });
        $("minesInfo").textContent = `✅ Забрал ${fmt(r.win)} ⭐ (x${r.multiplier.toFixed(2)})`;
        refreshMe(); notifyAch(r.achievements);
    } catch (e) { toast(e.message); }
});

// ---------- краш ----------
let crash = { running: false, elapsed: 0, recvAt: 0 };
let crashTimer = null, crashRaf = null;

function crashMultNow() {
    const t = crash.elapsed + (performance.now() - crash.recvAt) / 1000;
    return Math.exp(CFG.crash_growth * t);
}

function drawCrash() {
    if (!crash.running) return;
    const el = $("crashMult");
    el.textContent = `${(Math.floor(crashMultNow() * 100) / 100).toFixed(2)}x`;
    el.className = "crash-mult up";
    crashRaf = requestAnimationFrame(drawCrash);
}

function crashUI(running) {
    $("crashStart").disabled = running;
    $("crashCash").disabled = !running;
}

function crashFinish(r) {
    crash.running = false;
    clearInterval(crashTimer);
    cancelAnimationFrame(crashRaf);
    crashUI(false);
    const el = $("crashMult");
    if (r.status === "cashed") {
        el.textContent = `${r.multiplier.toFixed(2)}x`;
        el.className = "crash-mult up";
        $("crashStatus").textContent = `✅ Забрал +${fmt(r.payout)} ⭐`;
    } else {
        el.textContent = `${Number(r.crash_point).toFixed(2)}x`;
        el.className = "crash-mult dead";
        $("crashStatus").textContent = "💥 Крэш! Ставка потеряна";
    }
    if (r.stars !== undefined) setStars(r.stars);
    refreshMe(); notifyAch(r.achievements);
}

function crashBegin(r) {
    crash = { running: true, elapsed: r.elapsed || 0, recvAt: performance.now() };
    crashUI(true);
    $("crashStatus").textContent = r.auto ? `Идёт раунд · авто-вывод x${r.auto}` : "Идёт раунд...";
    cancelAnimationFrame(crashRaf);
    drawCrash();
    clearInterval(crashTimer);
    crashTimer = setInterval(async () => {
        try {
            const s = await api("/api/crash/state");
            if (s.status === "running") {
                crash.elapsed = s.elapsed; crash.recvAt = performance.now();
            } else if (s.status === "crashed" || s.status === "cashed") crashFinish(s);
            else { crash.running = false; clearInterval(crashTimer); crashUI(false); refreshMe(); }
        } catch (e) {}
    }, 400);
}

async function loadCrash() {
    try {
        const s = await api("/api/crash/state");
        if (s.status === "running") crashBegin(s);
        else if (s.status === "crashed" || s.status === "cashed") crashFinish(s);
        else crashUI(false);
    } catch (e) { toast(e.message); }
}

$("crashStart").addEventListener("click", async () => {
    try {
        const auto = parseFloat($("crashAuto").value);
        const r = await api("/api/crash/start", "POST", {
            bet: parseInt($("crashBet").value, 10), auto: auto > 0 ? auto : null
        });
        setStars(r.stars);
        crashBegin(r);
    } catch (e) { toast(e.message); }
});

$("crashCash").addEventListener("click", async () => {
    $("crashCash").disabled = true;
    try {
        crashFinish(await api("/api/crash/cashout", "POST"));
    } catch (e) { toast(e.message); }
});

// ---------- топ ----------
async function loadLeaderboard() {
    try {
        const d = await api("/api/leaderboard");
        $("leaderboard").innerHTML = d.players.length ? d.players.map((p, i) => `
            <div class="leader-row"><span>${i + 1}. ${esc(p.username || "Игрок")}</span>
            <strong>⭐ ${fmt(p.stars)}</strong></div>`).join("") : `<p class="muted">Пока нет игроков.</p>`;
    } catch (e) { $("leaderboard").innerHTML = `<p class="muted">${esc(e.message)}</p>`; }
}

// ---------- старт ----------
async function init() {
    try {
        CFG = await api("/api/config");
        $("bonusText").textContent = `Забирай ${CFG.bonus} ⭐ каждый день.`;
        renderDeposits();
        renderCases();
        await refreshMe();
    } catch (e) { toast(e.message); }
}
init();
